package com.project.services;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.project.daos.UserDao;
import com.project.dtos.Credential;
import com.project.dtos.DtoEntityConverter;
import com.project.dtos.UserDto;
import com.project.entities.User;

@Transactional
@Service
public class UserService {
	@Autowired
	private UserDao userDao;
	@Autowired
	private DtoEntityConverter conveter;
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public UserDto findUserById(int userId){
		User user = userDao.findByUserId(userId);
		return conveter.toUserDto(user);
	}
	
	public UserDto findUserByEmail(String email){
		User user = userDao.findByEmail(email);
		return conveter.toUserDto(user);
	} 
	
	//Validate user
	public UserDto findUserByEmailAndPassword(Credential cred) {
		User user=userDao.findByEmail(cred.getEmail());
		String rawPassword = cred.getPassword();
		if(user!=null && passwordEncoder.matches(rawPassword, user.getPassword())) {
			return conveter.toUserDto(user);
		}
		return null;
	}
	//signup
	public UserDto addUser(UserDto userdto) {
		String rawPassword = userdto.getPassword();
		String encrPassword = passwordEncoder.encode(rawPassword);
		
		userdto.setPassword(encrPassword);
		userDao.save(conveter.UserDtotoUser(userdto));
		return userdto;
	}
	
	//list of delivery boys
	public List<UserDto> deliveryBoysList(){
		List<User> list = userDao.findAll();
		List<UserDto> dlist = new ArrayList<>();
		
		for(User u: list) {
			if(u.getRole().equals("delivery"))
				dlist.add(conveter.toUserDto(u));
		}
		return dlist;
	}
	
	//List of customers
	public List<UserDto> getAllCustomers(){
		List<User> users=userDao.findAll();
		List<UserDto> userlist=new ArrayList<UserDto>();
		for(User u:users) {
			if(u.getRole().equals("user")) {
				userlist.add(conveter.toUserDto(u));
			}
		}
		return userlist;
	}
	
	//delete user
	public User deleteUser(int userId) {
		User u = userDao.findByUserId(userId);
		
		userDao.delete(u);
		return u;
	}
	
	//edit user
	public Map<String,Object> editUser(int userId,UserDto dto){
		User user = userDao.findByUserId(userId); 
		user.setUserName(dto.getUserName());
		user.setEmail(dto.getEmail());
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setPhone(dto.getPhone());
		user.setRole(dto.getRole());
		user.setAadharNo(dto.getAadharNo());
		user = userDao.save(user);
		return Collections.singletonMap("userChanged", 1);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
