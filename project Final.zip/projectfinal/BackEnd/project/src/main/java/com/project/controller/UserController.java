package com.project.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.project.dtos.Credential;
import com.project.dtos.Response;
import com.project.dtos.UserDto;
import com.project.services.UserService;

@CrossOrigin(origins = "*")
@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/user/{id}")
	public ResponseEntity<?> displayUserById(@PathVariable("id") int id){
		UserDto userDto = userService.findUserById(id);
		return Response.success(userDto);
	}
	
	//for signIn
	@PostMapping("/user/email")
	public ResponseEntity<?> signIn(@RequestBody Credential cred){
		UserDto userDto = userService.findUserByEmailAndPassword(cred);
		if(userDto==null)
			Response.error("Invalid username or password");
		return Response.success(userDto);
	}
	
	//Sign up
	@PostMapping("/signup/users")
	public ResponseEntity<?> signUp(@RequestBody UserDto userdto){
		UserDto result = userService.addUser(userdto);
		if(result==null)
			return Response.error("Something wrong happened");
		return Response.success(result);
	}
	
	//get all DeliveryBoys
	@PostMapping("/DeliveryBoys")
	public ResponseEntity<?> getAllDeliveryBoys(){
		return Response.success(userService.deliveryBoysList());			
	}
	
	//get all customers
	@GetMapping("/CustomerList")
	public ResponseEntity<?> getAllCustomers(){
		return Response.success(userService.getAllCustomers());			
	}
	
	//delete deliveryBoy
	@PostMapping("/DeliveryBoys/Delete")
	public ResponseEntity<?> deleteDeliveryBoy(@RequestBody ObjectNode objectNode){//@RequestBody ObjectNode objectNode
		int id = Integer.parseInt(objectNode.get("userId").asText());
		
		return Response.success(userService.deleteUser(id));
	}
	
	//edit user details
	@PutMapping("/user/edit")
	public ResponseEntity<?> editUser(@RequestBody UserDto dto){
		Map<String,Object> result = userService.editUser(dto.getUserId(), dto);
		return Response.success(result);
	}
	
	
	
	
	
	
	
	
	
	
	
}
